﻿namespace GiftAidCalculator.TestConsole.Services
{
    public interface IGiftAidCalculator
    {
        decimal Calculate(decimal donationAmount);
    }
}