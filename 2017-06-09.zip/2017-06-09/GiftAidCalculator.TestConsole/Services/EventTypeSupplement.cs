﻿namespace GiftAidCalculator.TestConsole.Services
{
    public enum EventTypeList
    {
        Running = 0,
        Swimming = 1,
        Other = 2
    }

    public class EventTypeSupplement : IEventTypeSupplement
    {
        public decimal AddSupplement(decimal number, EventTypeList eventType)
        {
            return number * GetEventSupplement(eventType);
        }

        decimal GetEventSupplement(EventTypeList eventType)
        {
            switch (eventType)
            {
                case EventTypeList.Running:
                    return 1.05m;
                case EventTypeList.Swimming:
                    return 1.03m;
                default:
                    return 1;
            }
        }
    }
}
