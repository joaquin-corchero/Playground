﻿namespace GiftAidCalculator.TestConsole.Services
{
    public interface IEventTypeSupplement
    {
        decimal AddSupplement(decimal number, EventTypeList eventType);
    }
}
