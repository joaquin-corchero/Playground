﻿namespace GiftAidCalculator.TestConsole.Services
{
    public class GiftAidOrchestrator : IGiftAidOrchestrator
    {
        readonly IGiftAidCalculator _giftAidCalculator;
        readonly INumberRounder _numberRounder;
        readonly IEventTypeSupplement _eventSupplement;

        public GiftAidOrchestrator() : this(new GiftAidCalculator(), new NumberRounder(), new EventTypeSupplement())
        { }

        public GiftAidOrchestrator(
            IGiftAidCalculator giftAidCalculator,
            INumberRounder numberRounder,
            IEventTypeSupplement eventSupplement
        )
        {
            _giftAidCalculator = giftAidCalculator;
            _numberRounder = numberRounder;
            _eventSupplement = eventSupplement;
        }


        public decimal CalculateGiftAid(decimal donationAmount, EventTypeList eventType)
        {
            var giftAid = _giftAidCalculator.Calculate(donationAmount);

            var withSupplement = _eventSupplement.AddSupplement(giftAid, eventType);

            var result = _numberRounder.Round(withSupplement, 2);            

            return result;
        }
    }
}
