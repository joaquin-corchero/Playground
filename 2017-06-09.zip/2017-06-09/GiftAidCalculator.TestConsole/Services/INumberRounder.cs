﻿namespace GiftAidCalculator.TestConsole.Services
{
    public interface INumberRounder
    {
        decimal Round(decimal number, int decimals);
    }
}
