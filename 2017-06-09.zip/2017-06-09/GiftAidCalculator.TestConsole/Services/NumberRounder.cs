﻿using System;

namespace GiftAidCalculator.TestConsole.Services
{
    public class NumberRounder : INumberRounder
    {
        public decimal Round(decimal number, int decimals)
        {
            return Math.Round(number, decimals);
        }
    }
}
