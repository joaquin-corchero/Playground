﻿namespace GiftAidCalculator.TestConsole.Services
{
    public interface IGiftAidOrchestrator
    {
        decimal CalculateGiftAid(decimal donationAmount, EventTypeList eventType);
    }
}
