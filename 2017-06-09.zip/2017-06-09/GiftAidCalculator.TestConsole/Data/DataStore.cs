﻿using GiftAidCalculator.TestConsole.Dtos;
using System.Collections.Generic;

namespace GiftAidCalculator.TestConsole.Data
{
    public interface IDataStore
    {
        IList<TaxRate> TaxRates { get;}
    }

    public class DataStore : IDataStore
    {
        public DataStore()
        {
            TaxRates = new List<TaxRate> {
                TaxRate.Generate(20.00m)
            };
        }

        public IList<TaxRate> TaxRates { get; }
    }
}
