﻿using NUnit.Framework;
using Moq;
using GiftAidCalculator.TestConsole.Services;
using GiftAidCalculator.TestConsole.Data;
using GiftAidCalculator.TestConsole.Dtos;

namespace GiftAidCalculator.Tests.Services
{
    [TestFixture]
    public class When_working_with_the_gift_aid_calculator_service
    {
        IGiftAidCalculator _giftAidCalculatorService;
        Mock<ITaxRateRepository> _taxRateRepository;

        [OneTimeSetUp]
        public void Setup()
        {
            _taxRateRepository = new Mock<ITaxRateRepository>();
            _giftAidCalculatorService = new TestConsole.Services.GiftAidCalculator(_taxRateRepository.Object);
        }

        [TestFixture]
        public class And_calculating_the_gift_aid : When_working_with_the_gift_aid_calculator_service
        {
            [OneTimeSetUp]
            public new void Setup()
            {
                _taxRateRepository.Setup(r => r.GetCurrentTaxRate()).Returns(TaxRate.Generate(20.00m));
            }

            [TestCase(100, ExpectedResult = 25)]
            [TestCase(111.11, ExpectedResult = 27.7775)]
            [TestCase(5.01, ExpectedResult = 1.2525)]
            [TestCase(0, ExpectedResult = 0)]
            public decimal Then_the_gift_aid_gets_calculated(decimal donationAmount)
            {
                return _giftAidCalculatorService.Calculate(donationAmount);
            }
        }
    }

}