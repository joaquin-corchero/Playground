﻿using GiftAidCalculator.TestConsole.Services;
using Moq;
using NUnit.Framework;

namespace GiftAidCalculator.Tests.Services
{
    [TestFixture]
    public class When_working_with_the_gift_aid_orchestrator
    {
        IGiftAidOrchestrator _giftAidOrchestrator;
        Mock<IGiftAidCalculator> _giftAidCalculator;
        Mock<INumberRounder> _numberRounder;
        Mock<IEventTypeSupplement> _eventTypeSupplement;

        [TestFixture]
        public class And_calculating_the_gift_aid : When_working_with_the_gift_aid_orchestrator
        {
            decimal _donationAmount = 10.01m;
            EventTypeList _eventType = EventTypeList.Other;
            decimal _giftAid = 0.2512m;
            decimal _supplierExtra = 0.2634m;
            decimal _roundedGiftAid = 0.26m;
            decimal _actual;

            [OneTimeSetUp]
            public void Setup()
            {
                _giftAidCalculator = new Mock<IGiftAidCalculator>();
                _numberRounder = new Mock<INumberRounder>();
                _eventTypeSupplement = new Mock<IEventTypeSupplement>();

                _giftAidCalculator.Setup(s => s.Calculate(_donationAmount)).Returns(_giftAid);
                _eventTypeSupplement.Setup(s => s.AddSupplement(_giftAid, _eventType)).Returns(_supplierExtra);
                _numberRounder.Setup(s => s.Round(_supplierExtra, 2)).Returns(_roundedGiftAid);                

                _giftAidOrchestrator = new GiftAidOrchestrator(
                    _giftAidCalculator.Object,
                    _numberRounder.Object,
                    _eventTypeSupplement.Object
                );

                _actual = _giftAidOrchestrator.CalculateGiftAid(_donationAmount, _eventType);
            }

            [TestCase]
            public void Then_the_gift_aid_calculator_is_called()
            {
                _giftAidCalculator.Verify(s => s.Calculate(_donationAmount), Times.Once);
            }

            [TestCase]
            public void Then_the_event_type_suplement_called()
            {
               _eventTypeSupplement.Verify(s => s.AddSupplement(_giftAid, _eventType));
            }

            [TestCase]
            public void Then_the_calculated_gift_aid_gets_rounded()
            {
                _numberRounder.Verify(s => s.Round(_supplierExtra, 2), Times.Once);
            }

            [Test]
            public void Then_the_final_amount_is_returned()
            {
                Assert.AreEqual(_actual, _roundedGiftAid);
            }
        }
    }
}
