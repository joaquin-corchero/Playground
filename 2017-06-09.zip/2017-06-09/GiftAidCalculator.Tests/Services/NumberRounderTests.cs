﻿using GiftAidCalculator.TestConsole.Services;
using NUnit.Framework;

namespace GiftAidCalculator.Tests.Services
{
    [TestFixture]
    public class When_working_with_the_number_rounder_service
    {
        INumberRounder _numberRounderService;

        [OneTimeSetUp]
        public void Setup()
        {
            _numberRounderService = new NumberRounder();
        }

        [TestFixture]
        public class And_rounding_a_number: When_working_with_the_number_rounder_service
        {
            [TestCase(1.316, 2, ExpectedResult = 1.32)]
            [TestCase(10.01, 1, ExpectedResult = 10.0)]
            [TestCase(10.01, 2, ExpectedResult = 10.01)]
            [TestCase(10.019, 2, ExpectedResult = 10.02)]
            [TestCase(10.499, 2, ExpectedResult = 10.50)]
            public decimal Then_the_number_gets_rounded_to_the_decimals(decimal number, int decimals)
            {
                return _numberRounderService.Round(number, decimals);
            }
        }
    }
}
