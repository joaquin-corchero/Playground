﻿using GiftAidCalculator.TestConsole.Data;
using GiftAidCalculator.TestConsole.Dtos;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace GiftAidCalculator.Tests.Data
{
    [TestFixture]
    public class When_working_with_the_tax_rate_repository
    {
        TaxRateRepository _taxRateRepository;
        Mock<IDataStore> _dataStore;

        [OneTimeSetUp]
        public void Setup()
        {
            _dataStore = new Mock<IDataStore>();
            _taxRateRepository = new TaxRateRepository(_dataStore.Object);
        }

        [TestFixture]
        public class And_getting_the_latest_tax_rate : When_working_with_the_tax_rate_repository
        {
            TaxRate _currentTaxRate;

            [OneTimeSetUp]
            public new void Setup()
            {
                var expiredTaxRate = TaxRate.Generate(17.00m);
                expiredTaxRate.Expire(new DateTime(2015, 04, 01));

                _currentTaxRate = TaxRate.Generate(20.00m);

                _dataStore.Setup(d => d.TaxRates).Returns(new List<TaxRate> { expiredTaxRate, _currentTaxRate });
            }

            [Test]
            public void Then_the_correct_tax_rate_is_returned()
            {
                Assert.AreEqual(_taxRateRepository.GetCurrentTaxRate(), _currentTaxRate);
            }
        }

        [TestFixture]
        public class And_adding_a_new_tax_rate : When_working_with_the_tax_rate_repository
        {
            [OneTimeSetUp]
            public new void Setup()
            {
                _dataStore.Setup(d => d.TaxRates).Returns(new List<TaxRate> { });
            }

            [Test]
            public void Then_a_tax_rate_can_be_added()
            {
                var expected = TaxRate.Generate(10.00m);
                _taxRateRepository.Add(expected);

                Assert.AreEqual(_taxRateRepository.GetCurrentTaxRate(), expected);
            }
        }
    }
}