﻿using System;

namespace GiftAidCalculator.TestConsole.Models
{
    public class TaxRate
    {
        public Guid Id { get; }

        public decimal Rate { get; }

        public DateTime? ExpiryDate { get; private set; }

        TaxRate(decimal rate)
        {
            Id = Guid.NewGuid();
            Rate = rate;
            ExpiryDate = null;
        }

        public static TaxRate Generate(decimal rate)
        {
            return new TaxRate(rate);
        }

        public void Expire(DateTime expiryDate)
        {
            ExpiryDate = expiryDate;
        }
    }
}
