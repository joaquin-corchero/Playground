﻿using GiftAidCalculator.TestConsole.Models;
using System.Linq;

namespace GiftAidCalculator.TestConsole.Data
{
    public interface ITaxRateRepository
    {
        TaxRate GetCurrentTaxRate();
    }

    public class TaxRateRepository : ITaxRateRepository
    {
        readonly IDataStore _dataStore;

        public TaxRateRepository() : this(new DataStore())
        { }

        public TaxRateRepository(IDataStore dataStore)
        {
            _dataStore = dataStore;
        }

        public TaxRate GetCurrentTaxRate()
        {
            return _dataStore.TaxRates.LastOrDefault(t=> t.ExpiryDate == null);
        }

        public void Add(TaxRate taxRate)
        {
            _dataStore.TaxRates.Add(taxRate);
        }
    }
}