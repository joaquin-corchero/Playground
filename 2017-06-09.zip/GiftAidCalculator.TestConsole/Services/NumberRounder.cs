﻿using System;

namespace GiftAidCalculator.TestConsole.Services
{
    public interface INumberRounder
    {
        decimal Round(decimal number, int decimals);
    }

    public class NumberRounder : INumberRounder
    {
        public decimal Round(decimal number, int decimals)
        {
            return Math.Round(number, decimals);
        }
    }
}
