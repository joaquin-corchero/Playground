﻿using GiftAidCalculator.TestConsole.Data;
using System;

namespace GiftAidCalculator.TestConsole.Services
{
    public interface IGiftAidCalculator
    {
        decimal Calculate(decimal donationAmount);
    }

    public class GiftAidCalculator : IGiftAidCalculator
    {
        readonly ITaxRateRepository _taxRateRepository;

        public GiftAidCalculator() : this(new TaxRateRepository())
        { }        

        public GiftAidCalculator(ITaxRateRepository taxRateRepository)
        {
            _taxRateRepository = taxRateRepository;
        }

        public decimal Calculate(decimal donationAmount)
        {
            var taxRate = _taxRateRepository.GetCurrentTaxRate().Rate;
            var gaRatio = taxRate / (100 - taxRate);

            return donationAmount * gaRatio;
        }
    }
}