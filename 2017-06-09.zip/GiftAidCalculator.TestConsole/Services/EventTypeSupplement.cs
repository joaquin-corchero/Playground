﻿namespace GiftAidCalculator.TestConsole.Services
{
    public enum EventTypeList
    {
        Running = 0,
        Swimming = 1,
        Other = 2
    }

    public interface IEventTypeSupplement
    {
        decimal AddSupplement(decimal number, EventTypeList eventType);
    }

    public class EventTypeSupplement : IEventTypeSupplement
    {
        public decimal AddSupplement(decimal number, EventTypeList eventType)
        {
            switch (eventType)
            {
                case EventTypeList.Running:
                    return number * 1.05m;
                case EventTypeList.Swimming:
                    return number * 1.03m;
                default:
                    return number;
            }
        }
    }
}
