﻿using GiftAidCalculator.TestConsole.Services;
using System;

namespace GiftAidCalculator.TestConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            IGiftAidOrchestrator orchestrator = new GiftAidOrchestrator();

            // Calc Gift Aid Based on Previous
            Console.WriteLine("Please Enter donation amount:");

            var value = decimal.Parse(Console.ReadLine());

            Console.WriteLine(orchestrator.CalculateGiftAid(value, EventTypeList.Other));
            Console.WriteLine("Press any key to exit.");
            Console.ReadLine();
        }
    }
}
