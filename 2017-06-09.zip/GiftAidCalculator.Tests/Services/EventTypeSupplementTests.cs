﻿using GiftAidCalculator.TestConsole.Services;
using NUnit.Framework;

namespace GiftAidCalculator.Tests.Services
{
    [TestFixture]
    public class When_working_with_the_event_type_supplement
    {
        IEventTypeSupplement _supplementService;

        [OneTimeSetUp]
        public void Setup()
        {
            _supplementService = new EventTypeSupplement();
        }

        public class And_adding_a_supplement : When_working_with_the_event_type_supplement
        {
            [TestCase(100.00, EventTypeList.Other, ExpectedResult = 100.00)]
            [TestCase(100.00, EventTypeList.Running, ExpectedResult = 105.00)]
            [TestCase(100.00, EventTypeList.Swimming, ExpectedResult = 103.00)]
            public decimal Then_the_correct_value_is_returned(decimal number, EventTypeList eventType)
            {
                return _supplementService.AddSupplement(number, eventType);
            }
        }
    }
}
